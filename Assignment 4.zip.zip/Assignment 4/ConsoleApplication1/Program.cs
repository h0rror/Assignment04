﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeatReservation
{
    /**
   * <summary>
   * Nikola Savin
   * 300635434
   * 
   * Main Program Class
   * This program allows the user to make a choice of airline seats between first class and economy sections.
   *
   * </summary>
   * @class Program
   */
    class Program
    {
        private static List<string> _chosenSeats;
        private static List<string> _availableSeats;


        static void Main(string[] args)
        {
            _availableSeats = new List<string>();
            _chosenSeats = new List<string>();

            for (int i = 0; i < 5; i++)
            {
                _availableSeats.Add("First Class");
            }
            for (int i = 0; i < 5; i++)
            {
                _availableSeats.Add("Economy");
            }

            DisplayMenu();
        }

        static void DisplayMenu()                                  //This displays the menu
        {
            string Choice;
            do
            {
                Console.WriteLine("1 First Class");
                Console.WriteLine("2 Economy");
                Console.WriteLine("3 Exit Menu");

                Console.Write("Choose either a First Class seat, or Economy, otherwise you can Exit by pressing 3. ");
                Choice = Console.ReadLine();

                switch (Choice)
                {
                    case "1":
                        FirstClass();
                        break;
                    case "2":
                        Economy();
                        break;
                    case "3":
                        break;
                    default:
                        Console.WriteLine("Please choose either 1,2, or 3.");
                        break;
                }
            } while (Choice != "3");
        }
        static void FirstClass()
        {
            if (_availableSeats.Remove("First Class"))
            {

                _chosenSeats.Add("First Class");                // this adds to chosenSeats
                Console.WriteLine("You chose First Class");
            }
            else
            {
                Console.Write("There are no more seats available in this section ");
                string answer = Console.ReadLine();
                if (answer == "yes" && _availableSeats.Remove("Economy"))
                {
                    _chosenSeats.Add("Economy");
                    Console.WriteLine("You chose Economy Class");
                }
                else
                {
                    Console.WriteLine("Check the departures screen for your flight schedule.");
                }
            }
        }
        static void Economy()
        {
            if (_availableSeats.Remove("Economy"))
            {

                _chosenSeats.Add("Economy");                // this adds to chosenSeats
                Console.WriteLine("You chose Economy Class");
            }
            else
            {
                Console.Write("This section is full, please choose another section. ");
                string answer = Console.ReadLine();
                if (answer == "yes" && _availableSeats.Remove("First Class"))
                {
                    _chosenSeats.Add("First Class");
                    Console.WriteLine("You Chose First Class");
                }
                else
                {
                    Console.WriteLine("Check the departures screen for your flight schedule.");
                }
            }
        }

        private static int Find(List<string> list, string item)
        {
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i] == item)
                {
                    return i;
                }

            }
            return -1;
        }
    }
}
