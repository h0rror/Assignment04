﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiceRoll
{  /**
    * <summary>
    *  Nikola Savin
    * 300635434
    * 
    * Main Driver Class
    * This program rolls 2d6 36000 times and then lists the results in a table.
    * 
    * </summary>
    * @class Program
    */
    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();

            int[] tracker = new int[13];                // Results are stored here

            for (int i = 0; i < 36000; i++)            // Rolls 2d6, 36 000 times
            {
                int d1 = random.Next(1, 7);            // 1d6(a)
                int d2 = random.Next(1, 7);            // 1d6(b)
                int sum = d1 + d2;                    // Adds 1d6(a) and 1d6(b) together
                tracker[sum]++;
            }

            Console.WriteLine("{0,-12} | {1,-8}", "Sum of Roll", "Dice Roll #");       // Lists the results of dice rolls
            Console.WriteLine("************************");

            for (int i = 2; i < tracker.Length; i++)
            {
                Console.WriteLine("{0,-12} | {1,-8}", i, tracker[i]);

            }

        }
    }
}